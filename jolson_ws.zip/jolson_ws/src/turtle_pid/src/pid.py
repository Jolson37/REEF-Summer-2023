#!/usr/bin/env python3
import rospy
import math
from geometry_msgs.msg import Twist
from tf.transformations import euler_from_quaternion, quaternion_from_euler
from nav_msgs.msg import Odometry

class turtle_pid_control():

    def __init__(self):

        self.goal_coord = [0.0,0.0,0.0]
        self.yaw_error = 0.0
        self.total_err = 0.0
        self.prev_err = 0.0
        self.total_err_lin = 0.0

        self.time_init = float()
        self.cur_time = float()

        self.set_gains()

        rospy.init_node("controller_node")
        self.odom_subscriber = rospy.Subscriber("/odom", Odometry, callback=self.read_odom_callback)
        self.cmd_publisher = rospy.Publisher("/cmd_vel", Twist, queue_size=10)

    def read_odom_callback(self, odom_data:Odometry):
        """Gets current position information from the odometer"""
        
        self.position = odom_data.pose.pose.position
        self.x = self.position.x
        self.y = self.position.y
        self.z = self.position.z
        self.w = 0.0
       
        self.orientation = odom_data.pose.pose.orientation

        rospy.loginfo(f"Current Position is: [{self.x},{self.y},{self.z}]")
        self.set_coordinates()

    def set_coordinates(self):
        if self.goal_coord == [0.0,0.0,0.0]:
            self.time_init = rospy.get_time()

        if -0.02 < self.x < 0.02 and -0.02 < self.y < 0.02:
            self.goal_coord = [5.0, 0.0, 0.0]
        elif 4.98 < self.x < 5.02 and -0.02 < self.y < 0.02:
            self.goal_coord = [5.0, 5.0, 0.0]
        elif 4.98 < self.x < 5.02 and 4.98 < self.y < 5.02:
            self.goal_coord = [0.0, 5.0, 0.0]
        elif -0.02 < self.x < 0.02 and 4.98 < self.y < 5.02:
            self.goal_coord = [0.0, 0.0, 0.0]

        rospy.loginfo(f"Going to: {self.goal_coord}")

        self.compute_pid()

    def compute_pid(self):        
        self.x_diff = self.goal_coord[0] - self.x
        self.y_diff = self.goal_coord[1] - self.y

        self.lin_err = math.sqrt(self.x_diff ** 2 + self.y_diff ** 2)

        orient_x = self.orientation.x
        orient_y = self.orientation.y
        orient_z = self.orientation.z
        orient_w = self.orientation.w
        ornt_quat_list = [orient_x, orient_y, orient_z, orient_w]
        [roll, pitch, yaw] = euler_from_quaternion(ornt_quat_list)
        self.cur_odom_euler = [roll, pitch, yaw]

        self.current_yaw = self.cur_odom_euler[2]
        self.desired_yaw = math.atan2(self.y_diff,self.x_diff)
        self.yaw_error = self.desired_yaw - self.current_yaw
        self.yaw_error = self.yaw_error * (180/math.pi)
        if self.yaw_error > 180:
            self.yaw_error = -(self.yaw_error - 180)
        if self.yaw_error < -180:
            self.yaw_error = (abs(self.yaw_error) - 180)
        self.yaw_error = self.yaw_error * (math.pi/180)

        # proportional
        self.prop_ang = self.kpa * self.yaw_error

        self.prop_lin = self.kpl * self.lin_err
        # integral
        self.prev_time = self.cur_time # prev time is the time of the last step
        self.cur_time = rospy.get_time() # get the time for the current step
        self.time_step = self.cur_time - self.prev_time # creates the time step
        if self.time_step > 0.1:
            self.time_step = 0.01
        rospy.loginfo(f"The time step is: {self.time_step}")
        self.prev_err = self.total_err # prev error is the error before this time step
        self.total_err += self.yaw_error * self.time_step # add the error from this time step to the previous error
        self.integral_ang = self.kia * self.total_err # integral error calculated for the angular direction
        if self.integral_ang > 1000: # limit the integral control to 1000 to avoid spinning
            self.integral_ang = self.kia * ((self.integral_ang / self.kia) - (self.yaw_error * self.time_step))
        
        self.prev_err_lin = self.total_err_lin # prev error is the error before this time step
        self.total_err_lin += self.lin_err * self.time_step # add the error from this time step to the previous error
        self.integral_lin = self.kil * self.total_err_lin # integral error calculated for the angular direction
        if self.integral_lin > 1000: # limit the integral control to 1000 to avoid spinning
            self.integral_lin = self.kil * ((self.integral_lin / self.kil) - (self.lin_err * self.time_step))
        self.integral_lin = self.kil * self.total_err_lin
        # derivative
        self.deriv_ang = self.kda * ((self.total_err - self.prev_err)/self.time_step)

        self.deriv_lin = self.kdl * ((self.total_err_lin - self.prev_err_lin)/self.time_step)
        # combine
        self.cntrl_out_ang = self.prop_ang + self.integral_ang + self.deriv_ang
        self.cntrl_out_lin = self.prop_lin + self.integral_lin + self.deriv_lin

        self.move_bot()

    def set_gains(self):
        self.kpa = 1
        self.kpl = 0.01
        self.kia = 0.001
        self.kil = 0.001
        self.kda = 1
        self.kdl = 0.1

    def move_bot(self):
        cmd = Twist()
        cmd.angular.z = self.cntrl_out_ang # Clockwise angular velocity
        if cmd.angular.z < 0.01:
            cmd.linear.x = self.cntrl_out_lin # Forward linear velocity
        self.cmd_publisher.publish(cmd)
        rospy.loginfo(cmd.linear.x)
        rospy.loginfo(cmd.angular.z)
        
        

    def run(self):
        rospy.spin()
    

if __name__ == "__main__":
    controller_node = turtle_pid_control()
    controller_node.run()