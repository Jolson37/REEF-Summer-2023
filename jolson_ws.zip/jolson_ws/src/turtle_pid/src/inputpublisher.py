#!/usr/bin/env python3
import rospy
from std_msgs.msg import Float32MultiArray


if __name__ == "__main__":
    rospy.init_node("coord_publisher_node")
    coord_publisher = rospy.Publisher("/new_coords", Float32MultiArray, queue_size=1)

    while not rospy.is_shutdown():
        x_coord = float(input("Enter desired x coordinate: "))
        y_coord = float(input("Enter desired y coordinate: "))
        #z_coord = float(input("Enter desired z coordinate: "))
        goal_coord = Float32MultiArray()
        goal_coord.data = [x_coord,y_coord]
        rospy.loginfo(f"Set to: {goal_coord.data}")
        coord_publisher.publish(goal_coord)