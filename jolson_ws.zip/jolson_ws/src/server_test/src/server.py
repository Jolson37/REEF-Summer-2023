#!/usr/bin/env python3

import rospy
from std_srvs.srv import SetBool, SetBoolResponse

def server_callback(req):
    response = SetBoolResponse()
    if req.data == True:
        response.success = "The device was enabled"
    else:
        response.success = True
    
    return response

rospy.init_node("server")
rospy.service("test_service",SetBool,server_callback)
rospy.spin()