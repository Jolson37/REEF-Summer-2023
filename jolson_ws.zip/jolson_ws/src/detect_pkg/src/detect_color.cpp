#include <iostream>

#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/videoio.hpp"
#include <cv_bridge/cv_bridge.h>
#include <image_transport/image_transport.h>
#include "sensor_msgs/image_encodings.h"
#include "ros/ros.h"
#include "std_msgs/Int32.h"


using namespace cv;
using namespace std;

namespace enc = sensor_msgs::image_encodings;

static const char WINDOW[] = "Image Processed";

image_transport::Publisher pub;

Mat imgOriginal;

std::string colorSeen = "color seen";

int image_received = 0;

void imageCallback(const sensor_msgs::ImageConstPtr& img)
{
    cv_bridge::CvImagePtr cv_ptr; //creates ptr
	cv_ptr = cv_bridge::toCvCopy(img, enc::BGR8); //copies the recieved image and saved it as ptr
	imgOriginal = cv_ptr->image; //turns ptr back to Mat
 	image_received = 1;	
}


int main( int argc, char** argv )
{
	ros::init(argc, argv, "image_processor"); // initialize node
	ros::NodeHandle n;
	ros::Publisher pub = n.advertise<std_msgs::Int32>("/color_seen", 1);
	image_transport::ImageTransport it(n); 
	image_transport::Subscriber sub = it.subscribe("/multirotor/camera/image_raw", 1, imageCallback);
	// image_transport::Publisher pub = it.advertise("/camera/color/image_raw", 1);

    namedWindow("Control", WINDOW_AUTOSIZE); //create a window called "Control"

    //modify these values to threshold a different color. Check the HSV color representation online.
    int iLowH = 0;
    int iHighH = 90;

    int iLowS = 0;
    int iHighS = 0;

    int iLowV = 88;
    int iHighV = 255;

    //Create trackbars in "Control" window
    createTrackbar("LowH", "Control", &iLowH, 179); //Hue (0 - 179)
    createTrackbar("HighH", "Control", &iHighH, 179);

    createTrackbar("LowS", "Control", &iLowS, 255); //Saturation (0 - 255)
    createTrackbar("HighS", "Control", &iHighS, 255);

    createTrackbar("LowV", "Control", &iLowV, 255); //Value (0 - 255)
    createTrackbar("HighV", "Control", &iHighV, 255);

    int iLastX = -1;
    int iLastY = -1;

	while (image_received == 0)
	{
		ros::spinOnce();
	}

    //Create a black image with the size as the camera output
    Mat imgLines = Mat::zeros(imgOriginal.size(), CV_8UC3 );

    while(true)
    {
		Mat imgHSV;

    	cvtColor(imgOriginal, imgHSV, COLOR_BGR2HSV); //Convert the captured frame from BGR to HSV

    	Mat imgThresholded;

    	inRange(imgHSV, Scalar(iLowH, iLowS, iLowV), Scalar(iHighH, iHighS, iHighV), imgThresholded); //Threshold the image

//    	//morphological opening (remove small objects from the foreground)
    	erode(imgThresholded, imgThresholded, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)) );
    	dilate( imgThresholded, imgThresholded, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)) );

    	//morphological closing (fill small holes in the foreground)
    	dilate( imgThresholded, imgThresholded, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)) );
    	erode(imgThresholded, imgThresholded, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)) );

    	//Calculate the moments of the thresholded image
    	Moments oMoments = moments(imgThresholded);

    	double dM01 = oMoments.m01;
    	double dM10 = oMoments.m10;
    	double dArea = oMoments.m00;
//    	cout<<"moment10= "<<dM10<<endl;
//    	cout<<"Area is this= "<<dArea<<endl;

    	// if the area <= 10000, I consider that the there are no object in the image and it's because of the noise, the area is not zero
    	if (dArea > 500000)
    	{
        	//calculate the position of the ball
        	int posX = dM10 / dArea;
        	int posY = dM01 / dArea;
        
        	if (iLastX >= 0 && iLastY >= 0 && posX >= 0 && posY >= 0)
        	{
            	//Draw a colored line from the previous point to the current point
            	line(imgLines, Point(posX, posY), Point(iLastX, iLastY), Scalar(0,0,255), 2);
				std_msgs::Int32 msg;
				msg.data = 1;
				pub.publish(msg);
        	}

        	iLastX = posX;
        	iLastY = posY;
    	}
		else
		{
			std_msgs::Int32 msg;
			msg.data = 0;
			pub.publish(msg);
		}

    	imshow("Thresholded Image", imgThresholded); //show the thresholded image
    	imgOriginal = imgOriginal + imgLines;
    	imshow("Original", imgOriginal);// show the original image

		if (waitKey(30) == 27) //wait for 'esc' key press for 30ms. If 'esc' key is pressed, break loop
        {
            cout << "esc key is pressed by user" << endl;
            break;
        }
		ros::spinOnce();
	}
	return 0;
}

