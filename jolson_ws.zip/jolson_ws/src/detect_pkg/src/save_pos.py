#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Point


class save_pos():

    def __init__(self):
        self.point_list = []
        self.new_point = False

        rospy.init_node("save_pos")
        self.sub = rospy.Subscriber("/pos_check",Point,callback = self.pos_callback)   
        self.pub = rospy.Publisher("/point_list",Point,queue_size=10) 

    def pos_callback(self, pos:Point):
        Dupe = False
        i = 0
        for item in self.point_list:
            check_point:Point = item
            x = check_point.x
            y = check_point.y
            z = check_point.z
            if Dupe == True:
                break
            if abs(pos.x - x) < 2 and abs(pos.y - y) < 2 and abs(pos.z - z) < 2:
                Dupe = True
            i += 1

        if Dupe == False:
            rospy.loginfo("added a point")
            self.point_list.append(pos)
            self.pub.publish(pos)
            self.new_point = True
    
    # def send_points(self):
    #     if self.new_point == True:
    #         for item in self.point_list:
    #             self.pub.publish(item)
    #         self.new_point = False

    def run(self):
        rospy.spin()
    

if __name__ == "__main__":
    controller_node = save_pos()
    controller_node.run()