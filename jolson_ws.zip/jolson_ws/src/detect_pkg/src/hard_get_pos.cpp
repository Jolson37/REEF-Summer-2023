#include <iostream>

#include "vector"
#include "ros/ros.h"
#include "std_msgs/Int32.h"
#include "geometry_msgs/PoseStamped.h"

using namespace std;

geometry_msgs::Point pos;
int val = 0;
int valCheck = 1;

ros::Publisher posPub;

void getPosCallback(const geometry_msgs::PoseStamped::ConstPtr& poseData)
{
    geometry_msgs::Pose pose = poseData->pose;
    // x = pose.position.x;
    // y = pose.position.y;
    // z = pose.position.z;
    pos = pose.position;
    // ROS_INFO("Point: x=%.2f, y=%.2f, z=%.2f",pos.x,pos.y,pos.z);
    if (val == valCheck)
    {
        posPub.publish(pos);
    }
}

void objectCallback(const std_msgs::Int32::ConstPtr& msg)
{
    int value = msg->data;
    val = value;
}

int main( int argc, char** argv )
{
    ros::init(argc, argv, "get_pos"); // initialize node
    ros::NodeHandle n;
    ros::Subscriber colorSub = n.subscribe<std_msgs::Int32>("/color_seen",1, objectCallback);
    ros::Subscriber odomSub = n.subscribe<geometry_msgs::PoseStamped>("/pose_stamped",1, getPosCallback);
    posPub = n.advertise<geometry_msgs::Point>("/pos_check",10);
        
    
    // ROS_INFO("Check: %d",valCheck);
    // ROS_INFO("Val: %d",val);
    
    ros::spin();
}