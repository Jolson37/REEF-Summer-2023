#!/usr/nim/env python3
import rospy

if __name__ == '__main__':
    rospy.init_node("tester_node")

    rospy.loginfo("Message from tester node")
    rospy.logwarn("WARNING")
    rospy.logerr("ERROR")

    rospy.sleep(1.0)

    rospy.loginfo("THE END")
