#!/usr/bin/env python3
import rospy
from turtlesim.msg import Pose #import msg Pose from turtlesim package
from geometry_msgs.msg import Twist

def pose_callback(pose: Pose): # need to make sure you are publishing the correct type
    cmd = Twist() # create a message
    if pose.x > 9.0 or pose.x < 2.0 or pose.y > 9.0 or pose.y < 2.0:
        cmd.linear.x = 1.0
        cmd.angular.z = 0.7
    else:
        cmd.linear.x = 5.0 # fill with fields
        cmd.angular.z = 0.0

    pub.publish(cmd)
    # publish the message in a subscriber callback,
    # so it will not publish anything if it doesn't receive anything

    
    # a very simple callback function is to print what is recieved

if __name__== '__main__':
    rospy.init_node("turtle_controller")
    pub = rospy.Publisher("/turtle1/cmd_vel", Twist, queue_size=10)
    sub = rospy.Subscriber("/turtle1/pose", Pose, callback=pose_callback)
    rospy.loginfo('Node has been STARTED YEAH!!!')

    rospy.spin()

    