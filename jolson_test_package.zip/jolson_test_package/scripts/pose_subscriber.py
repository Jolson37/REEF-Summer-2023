#!/usr/bin/env python3
import rospy
from turtlesim.msg import Pose #import msg Pose from turtlesim package

def pose_callback(msg: Pose):
    rospy.loginfo("(" + str(msg.x) + ", " + str(msg.y) + ")") 
    
    # a very simple callback function is to print what is recieved

if __name__== '__main__':
    rospy.init_node("turtle pose subscriber")

    sub = rospy.Subscriber("/turtle1/pose", Pose, callback=pose_callback)
    # for a subscriber you need the name of the topic, the type, and a callback function 
    # to process the message

    rospy.loginfo('Node has been STARTED YEAH!!!')

    # the subscriber will close unless you do something to keep it open, 
    # such as a while loop and a rate, or rospy.spin()

    rospy.spin()
