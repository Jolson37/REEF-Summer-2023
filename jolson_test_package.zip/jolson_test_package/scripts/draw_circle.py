#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist # import data type from package geometry_msgs

if __name__ == '__main__':
    rospy.init_node("draw_circle") # initialize the node
    rospy.loginfo("Node Started") # communicate that the node has started

    pub = rospy.Publisher("/turtle1/cmd_vel", Twist, queue_size=10)
    # Queue size is a buffer that holds a number of messages for a subscriber

    # cmd_vel is a topic, this program is a node that 
    # publsihes the msg on the cmd_vel topic

    rate = rospy.Rate(2) # rate set to 2 hz

    while not rospy.is_shutdown():
        msg = Twist()
        msg.linear.x = 2.0
        msg.angular.z = 1.0
        pub.publish(msg)
        rate.sleep() # run loop at the set rate
